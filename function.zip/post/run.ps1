using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

Push-OutputBinding -Name Response -Clobber -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body       = 'Result are being validated, please wait....'
})

Invoke-Challenge -flagCode "$($Request.Query.code)"
$result = [ordered]@{
    'UserAccount'       = "$($user.UserName)"
    'Password'          = "$($user.Password)"
    'Storage Account'   = "$($resources.properties.outputs.storageAccountName.value)"
}

