using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

Invoke-Challenge -flagCode "$($Request.Query.code)"
$result = [ordered]@{
    'UserAccount'       = "$($user.UserName)"
    'Password'          = "$($user.Password)"
    'Storage Account'   = "$($resources.properties.outputs.storageAccountName.value)"
}

    Push-OutputBinding -Name Response -Clobber -Value ([HttpResponseContext]@{
            StatusCode = [HttpStatusCode]::OK
            Body       = $result
        })
